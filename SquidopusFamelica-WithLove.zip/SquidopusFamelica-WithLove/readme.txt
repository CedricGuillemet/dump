                                                                   
 ,---.                 ,--.   ,--.                                 
'   .-'  ,---. ,--.,--.`--' ,-|  | ,---.  ,---. ,--.,--. ,---.     
`.  `-. | .-. ||  ||  |,--.' .-. || .-. || .-. ||  ||  |(  .-'     
.-'    |' '-' |'  ''  '|  |\ `-' |' '-' '| '-' ''  ''  '.-'  `)    
`-----'  `-|  | `----' `--' `---'  `---' |  |-'  `----' `----'     
           `--'                          `--'                      
            ,------.                        ,--.,--.               
            |  .---',--,--.,--,--,--. ,---. |  |`--' ,---. ,--,--. 
            |  `--,' ,-.  ||        || .-. :|  |,--.| .--'' ,-.  | 
            |  |`  \ '-'  ||  |  |  |\   --.|  ||  |\ `--.\ '-'  | 
            `--'    `--`--'`--`--`--' `----'`--'`--' `---' `--`--' 
                                                                   

64Kb intro
    /With Love

This demo is a prequel to Equiratis Rodentus (Evoke 24)

 .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  
=`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'=
   "      "      "      "      "      "      "      "   

Squidopus  famelica  is  characterized by its insatiable
hunger.  It  is  a  voracious  predator,  constantly  on
the  hunt and willing to consume anything that is alive.
This  relentless  appetite  drives  its behavior, making
it  an  aggressive and opportunistic feeder. It displays
a high degree of cunning and intelligence, often setting
traps  for its prey or ambushing them with a combination
of stealth and speed.

 .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  
=`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'=
   "      "      "      "      "      "      "      "   

Direction/Code/Art by Cedric
Audio by Alkama

Additional Storyboard and reviews by Thermostat and Eric
Kernin.
Sky shader is a mix of:
https://www.shadertoy.com/view/MX2yRV
and atmosphere scattering.

 .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  
=`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'=
   "      "      "      "      "      "      "      "   

Greetings

Doctor Gekil / LLB / Babylon.js team / Guillaume Boisse
Stef / Future Crew / Omar Cornut / Flure / Editions 64K
Jon / Thermostat / Speedman / Evoke orgas / Judge Drokk
Guille  /  Spectrals / Alex Evans / Team210 / Totetmatt
Dok / Virgill / Anarchy / Peregrine / Leonard / Flopine
Dune / Divide / NoFrag / G33kou / TRSI / Mooz / Zerkman
Rubix / Triton / Nusan  / drift / Darya / MrVux / Zavie 

And every one I've met at parties !

https://bsky.app/profile/skaven.bsky.social

MMXXVI With Love